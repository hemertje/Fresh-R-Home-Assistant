#!/usr/bin/env python3
"""
Fresh-r integration — validatie & simulatie
============================================
Verifieert alle componenten met echte HAR-data zonder Home Assistant nodig.

Uitvoeren:  python3 validate_and_simulate.py
"""

import asyncio
import json
import sys
from pathlib import Path
from datetime import datetime, timezone

# ── 1. Syntaxvalidatie alle Python modules ─────────────────────────────────────

import ast

ROOT = Path(__file__).parent / "custom_components" / "fresh_r"
PY_FILES = list(ROOT.glob("*.py")) + list(ROOT.glob("**/*.py"))

print("=" * 60)
print("1. Python syntaxvalidatie")
print("=" * 60)
errors = 0
for f in sorted(PY_FILES):
    try:
        ast.parse(f.read_text())
        print(f"  ✓  {f.name}")
    except SyntaxError as e:
        print(f"  ✗  {f.name}: {e}")
        errors += 1
if errors:
    print(f"\n✗ {errors} syntaxfout(en) gevonden")
    sys.exit(1)

# ── 2. JSON validatie ─────────────────────────────────────────────────────────

print()
print("=" * 60)
print("2. JSON validatie")
print("=" * 60)

json_files = list(ROOT.glob("*.json")) + list(ROOT.glob("**/*.json"))
json_files += list((Path(__file__).parent / "grafana").glob("*.json"))
for f in sorted(json_files):
    try:
        data = json.loads(f.read_text())
        print(f"  ✓  {f.relative_to(Path(__file__).parent)}")
    except json.JSONDecodeError as e:
        print(f"  ✗  {f}: {e}")
        errors += 1

# ── 3. Importeer en valideer api.py logica ────────────────────────────────────

print()
print("=" * 60)
print("3. API logica — calibratie & berekeningen")
print("=" * 60)

# Import api module direct (without HA)
import importlib.util, types

def load_module(name: str, path: Path):
    # Inject minimal stub for .const import
    const_path = path.parent / "const.py"
    const_spec = importlib.util.spec_from_file_location("fresh_r.const", const_path)
    const_mod = importlib.util.module_from_spec(const_spec)
    const_spec.loader.exec_module(const_mod)
    sys.modules["fresh_r.const"] = const_mod
    sys.modules[".const"] = const_mod

    spec = importlib.util.spec_from_file_location(name, path)
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod


api = load_module("fresh_r.api", ROOT / "api.py")

# Test flow calibration
cases = [
    (100,  100.0),   # normal: no correction
    (200,  200.0),   # normal: no correction
    (756,  21.9),   # ESP mode: (756-700)/30+20 = 21.9 (allow small rounding)
    (1432, 44.4),    # from HAR: first chart-data point
    (991,  29.7),    # from HAR: last chart-data point
]

print("\n  Flow calibration (raw → m³/h):")
cal_errors = 0
for raw, expected in cases:
    got = round(api.calibrate_flow(raw), 1)
    ok  = abs(got - expected) < 1.0   # allow 1 m³/h tolerance
    mark = "✓" if ok else "✗"
    print(f"  {mark}  raw={raw:5} → {got:5.1f}  (verwacht ≈ {expected})")
    if not ok:
        cal_errors += 1

# Test derived sensors with real values from HAR
print("\n  Afgeleide sensoren (t1=21.5, t2=18.3, t4=19.9, flow=21.9):")
t1, t2, t3, t4 = 21.5, 18.3, 20.0, 19.9
flow = round(api.calibrate_flow(756), 1)
data = {"t1": t1, "t2": t2, "t3": t3, "t4": t4, "flow": flow}
derived = api.derive(data)
print(f"  ✓  flow gecalibreerd:   {flow} m³/h")
print(f"  ✓  warmteterugwinning:  {derived['heat_recovered']} W")
print(f"  ✓  ventilatieverl ref:  {derived['vent_loss']} W")
print(f"  ✓  energieverlies:      {derived['energy_loss']} W")

# Sanity check physics
assert derived['heat_recovered'] >= 0, "heat_recovered must be ≥ 0"
assert derived['vent_loss']      >= 0, "vent_loss must be ≥ 0"
assert derived['energy_loss']    >= 0, "energy_loss must be ≥ 0"
print("  ✓  fysica sanity checks geslaagd")

# ── 4. Parse echte HAR data ───────────────────────────────────────────────────

print()
print("=" * 60)
print("4. Simulatie met echte HAR-data")
print("=" * 60)

HAR_PATH = Path("/mnt/user-data/uploads/dashboard_bw-log_com.har")
if not HAR_PATH.exists():
    print("  ⚠  HAR bestand niet gevonden — simulatie overgeslagen")
else:
    with open(HAR_PATH) as f:
        har = json.load(f)

    import urllib.parse
    entries = har["log"]["entries"]

    # Find current-data entry
    current_entry = None
    chart_entry   = None
    for e in entries:
        url   = e["request"]["url"]
        q_raw = urllib.parse.parse_qs(urllib.parse.urlparse(url).query).get("q", [""])[0]
        try:
            q = json.loads(q_raw)
            for k, v in q.get("requests", {}).items():
                req = v.get("request", "")
                if req == "fresh-r-now":
                    current_entry = e
                elif req == "fresh-r-day":
                    chart_entry = e
        except Exception:
            pass

    if current_entry:
        resp = json.loads(current_entry["response"]["content"]["text"])
        raw  = resp.get("current-data", {})
        print(f"\n  Actuele data ({raw.get('date', '?')}):")
        parsed = api.FreshRApiClient.__new__(api.FreshRApiClient)
        parsed._parse = api.FreshRApiClient._parse.__get__(parsed, api.FreshRApiClient)
        result = parsed._parse(raw)
        for k, v in sorted(result.items()):
            if k != "timestamp":
                print(f"    {k:25} = {v}")

        print(f"\n  Validatie:")
        assert result.get("t1") == 21.5, f"t1 mismatch: {result.get('t1')}"
        assert result.get("co2") == 681.0, f"co2 mismatch: {result.get('co2')}"
        assert result.get("flow") is not None, "flow missing"
        assert result.get("heat_recovered") is not None, "heat_recovered missing"
        print("  ✓  alle verwachte velden aanwezig en correct")

    if chart_entry:
        resp  = json.loads(chart_entry["response"]["content"]["text"])
        rows  = resp.get("chart-data", [])
        print(f"\n  Historische data: {len(rows)} datapunten (10-minuten intervallen)")
        assert len(rows) > 0, "Geen chart-data gevonden"

        # Parse all rows
        parsed_rows = []
        dummy = api.FreshRApiClient.__new__(api.FreshRApiClient)
        dummy._parse = api.FreshRApiClient._parse.__get__(dummy, api.FreshRApiClient)
        for row in rows:
            p = dummy._parse(row)
            try:
                ts = datetime.fromisoformat(str(row["date"]))
                if ts.tzinfo is None:
                    ts = ts.replace(tzinfo=timezone.utc)
                p["timestamp"] = ts
            except (KeyError, ValueError):
                pass
            parsed_rows.append(p)

        print(f"  ✓  {len(parsed_rows)} rijen correct geparsed")
        print(f"  ✓  eerste: {parsed_rows[0].get('timestamp', '?')}")
        print(f"  ✓  laatste: {parsed_rows[-1].get('timestamp', '?')}")

        # Spot check first row
        r0 = parsed_rows[0]
        assert r0.get("t1")   == 20.2, f"row0 t1: {r0.get('t1')}"
        assert r0.get("t2")   == 13.1, f"row0 t2: {r0.get('t2')}"
        assert r0.get("co2")  == 958.0, f"row0 co2: {r0.get('co2')}"
        assert r0.get("flow") is not None, "row0 flow missing"
        print(f"  ✓  spot-check eerste rij geslaagd (t1={r0['t1']}, co2={r0['co2']})")

# ── 5. MQTT topic check ────────────────────────────────────────────────────────

print()
print("=" * 60)
print("5. MQTT topics")
print("=" * 60)

# Load mqtt module
const_spec = importlib.util.spec_from_file_location("fresh_r.const", ROOT / "const.py")
const_mod  = importlib.util.module_from_spec(const_spec)
const_spec.loader.exec_module(const_mod)

serial = "e:232212/180027"
did    = serial.replace(":", "_").replace("/", "_")
state  = f"fresh_r/{did}/state"
avail  = f"fresh_r/{did}/availability"
disc   = f"homeassistant/sensor/fresh_r_{did}_co2/config"

print(f"  State topic:  {state}")
print(f"  Avail topic:  {avail}")
print(f"  Disc (co2):   {disc}")
print(f"  ✓  {len(const_mod.SENSORS)} sensoren gedefinieerd")
print("  ✓  MQTT topics correct opgebouwd")

# ── 6. Grafana dashboard validatie ────────────────────────────────────────────

print()
print("=" * 60)
print("6. Grafana dashboard validatie")
print("=" * 60)

gf_path = Path(__file__).parent / "grafana" / "fresh_r_dashboard.json"
gf = json.loads(gf_path.read_text())
panels = [p for p in gf["panels"] if p.get("type") != "row"]
rows   = [p for p in gf["panels"] if p.get("type") == "row"]

print(f"  ✓  Dashboard geladen: {gf['title']}")
print(f"  ✓  {len(panels)} panelen, {len(rows)} rijen")

expected_panels = ["CO2", "Binnentemperatuur", "Debiet", "Vochtigheid",
                   "Warmteterugwinning", "CO2 (ppm)", "Temperaturen",
                   "Luchtdebiet", "Warmte (W)", "PM2.5"]
for ep in expected_panels:
    found = any(ep.lower() in p.get("title", "").lower() for p in panels)
    print(f"  {'✓' if found else '✗'}  Panel '{ep}' {'aanwezig' if found else 'ONTBREEKT'}")
    if not found:
        errors += 1

# ── Eindresultaat ──────────────────────────────────────────────────────────────

print()
print("=" * 60)
if errors == 0:
    print("✅  ALLE TESTS GESLAAGD — systeem klaar voor installatie")
else:
    print(f"❌  {errors} fout(en) gevonden")
    sys.exit(1)
print("=" * 60)
