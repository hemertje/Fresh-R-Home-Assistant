# Fresh-R Home Assistant Integration

## 🎯 HA-Vriendelijke Installatie

Deze ZIP bevat de Fresh-R Home Assistant integratie met een perfecte HA-installatie structuur.

## 📦 Installatie Instructies

### Stap 1: Download en Extract
1. Download deze ZIP file
2. Extract naar een tijdelijke locatie
3. Je ziet nu een `Home_Assistant_Installation` map

### Stap 2: Kopieer naar Home Assistant
```bash
# Kopieer de custom components
cp -r Home_Assistant_Installation/custom_components/fresh_r <HA-config>/custom_components/

# Kopieer de Lovelace card
cp Home_Assistant_Installation/www/fresh-r-card.js <HA-config>/www/
cp Home_Assistant_Installation/www/fresh-r-dashboard.yaml <HA-config>/www/
```

### Stap 3: Configureer Home Assistant
1. Herstart Home Assistant
2. Ga naar Settings → Devices & Services
3. Voeg Fresh-R integratie toe
4. Configureer met je Fresh-R credentials

### Stap 4: Voeg Lovelace Card Toe
In Home Assistant → Settings → Dashboards → Resources:
- URL: `/local/fresh-r-card.js`
- Type: `JavaScript module`

## 🎨 Wat is Inbegrepen

### Home Assistant Integratie
- ✅ Complete Fresh-R API client
- ✅ Multi-language support (EN, NL, DE, FR)
- ✅ Rate limiting protection
- ✅ Custom Fresh-R logo
- ✅ 20+ sensors (temperatuur, CO2, luchtstroom, etc.)

### Lovelace Card
- ✅ Multi-language dashboard card
- ✅ Real-time data visualisatie
- ✅ Automatische taaldetectie

### Dashboard
- ✅ Complete Lovelace dashboard configuratie
- ✅ Grafana dashboard (optioneel)

## 🌍 Multi-language Support

De Fresh-R integratie ondersteunt 4 talen:
- 🇬🇧 **English** - Full English interface
- 🇳🇱 **Nederlands** - Volledig Nederlandse interface  
- 🇩🇪 **Deutsch** - Vollständige Deutsche Oberfläche
- 🇫🇷 **Français** - Interface française complète

De taal wordt automatisch gedetecteerd op basis van je Home Assistant taalinstelling.

## 🛡️ Safety Features

- **Rate Limiting:** Maximaal 12 requests per uur
- **Token Management:** Automatische refresh
- **Error Handling:** Robuste foutafhandeling
- **Production Ready:** Volledig getest

## 📞 Support

- **GitHub:** https://github.com/hemertje/Fresh-R-Home-Assistant
- **Issues:** https://github.com/hemertje/Fresh-R-Home-Assistant/issues
- **Documentation:** https://github.com/hemertje/Fresh-R-Home-Assistant/blob/main/README.md

---

**Fresh-R Integration v2.0.6** - Ready for Home Assistant! 🚀
