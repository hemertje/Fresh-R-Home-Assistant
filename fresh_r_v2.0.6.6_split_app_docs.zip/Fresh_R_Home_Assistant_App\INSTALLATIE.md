# Fresh-R Home Assistant App - Installatie

## 🎯 Alleen wat je nodig hebt voor Home Assistant!

Deze map bevat **alleen de Fresh-R HA App bestanden** - geen extra documentatie of test files.

## 📦 Minimalistische Installatie

### Stap 1: Kopieer naar Home Assistant
```bash
# Kopieer de custom components
cp -r Fresh_R_Home_Assistant_App/custom_components/fresh_r <HA-config>/custom_components/

# Kopieer de Lovelace card
cp Fresh_R_Home_Assistant_App/www/fresh-r-card.js <HA-config>/www/
cp Fresh_R_Home_Assistant_App/www/fresh-r-dashboard.yaml <HA-config>/www/
```

### Stap 2: Configureer Home Assistant
1. Herstart Home Assistant
2. Ga naar Settings → Devices & Services
3. Voeg Fresh-R integratie toe
4. Configureer met je Fresh-R credentials

### Stap 3: Voeg Lovelace Card Toe
In Home Assistant → Settings → Dashboards → Resources:
- URL: `/local/fresh-r-card.js`
- Type: `JavaScript module`

## 🎨 Wat is inbegrepen

### ✅ Home Assistant Integration
- Complete Fresh-R API client
- Multi-language support (EN, NL, DE, FR)
- Rate limiting protection
- Custom Fresh-R logo
- 20+ sensors (temperatuur, CO2, luchtstroom, etc.)

### ✅ Lovelace Card
- Multi-language dashboard card
- Real-time data visualisatie
- Automatische taaldetectie
- Complete dashboard configuratie

## 🌍 Multi-language Support

De Fresh-R integratie ondersteunt 4 talen:
- 🇬🇧 **English** - Full English interface
- 🇳🇱 **Nederlands** - Volledig Nederlandse interface  
- 🇩🇪 **Deutsch** - Vollständige Deutsche Oberfläche
- 🇫🇷 **Français** - Interface française complète

De taal wordt automatisch gedetecteerd op basis van je Home Assistant taalinstelling.

## 🛡️ Safety Features

- **Rate Limiting:** Maximaal 12 requests per uur
- **Token Management:** Automatische refresh
- **Error Handling:** Robuste foutafhandeling
- **Production Ready:** Volledig getest

## 📞 Volledige Documentatie

Voor complete documentatie, Grafana dashboards, FAQ's en test files:
- Zie de `Documentatie_en_Divers/` map
- Of bezoek: https://github.com/hemertje/Fresh-R-Home-Assistant

---

**Fresh-R Home Assistant App v2.0.6** - Ready for Home Assistant! 🚀

**Alleen de HA App - geen extra bestanden!** ✅
