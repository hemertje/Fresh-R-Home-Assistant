# Fresh-R Documentatie en Diverse Bestanden

## 📚 Complete Documentatie, Tools en Resources

Deze map bevat **alle documentatie, Grafana dashboards, test tools en GitHub workflows** - geen HA App bestanden.

## 🎯 Wat is inbegrepen

### 📖 Documentatie
- **README.md** - Complete handleiding en documentatie
- **docs/** - FAQ, installatie guides, dashboard configuraties
- **LICENSE** - MIT license

### 📊 Grafana Dashboards
- **grafana/** - Professionele Grafana dashboard JSON
- Import-ready voor data visualisatie
- Complete Fresh-R sensor visualisatie

### 🛠️ Development Tools
- **tests/** - Python test scripts
  - `test_fresh_r.py` - API testing tool
  - `test_fresh_r_standalone.py` - Standalone validator
- **github/** - GitHub Actions workflows
  - Automated releases
  - CI/CD pipelines

### 🌍 Multi-Language Support
- Complete documentatie in 4 talen
- Grafana dashboards per taal
- Installatie handleidingen

## 📋 Gebruik

### Voor Gebruikers
- **FAQ:** `docs/FAQ.md` - Veelgestelde vragen
- **Grafana:** `grafana/fresh_r_dashboard.json` - Import in Grafana
- **Dashboard:** `docs/fresh_r_lovelace_dashboard.yaml` - Lovelace configuratie

### Voor Developers
- **Tests:** `tests/` - API validation en testing
- **GitHub:** `github/` - Workflow templates
- **Documentation:** `README.md` - Complete technische documentatie

## 🚀 Quick Start

### Grafana Dashboard Importeren
1. Open Grafana
2. Importeer `grafana/fresh_r_dashboard.json`
3. Verbind met je InfluxDB datasource
4. Geniet van de visualisatie

### Fresh-R App Installatie
- Gebruik de `Fresh_R_Home_Assistant_App/` map voor de HA integratie
- Deze map bevat alleen de benodigde HA bestanden

## 📞 Support

- **GitHub:** https://github.com/hemertje/Fresh-R-Home-Assistant
- **Issues:** https://github.com/hemertje/Fresh-R-Home-Assistant/issues
- **Documentation:** `README.md` voor complete technische details

---

**Fresh-R Documentatie v2.0.6** - Complete Resources! 📚

**Alleen documentatie en tools - geen HA App bestanden!** ✅
